import React from "react";

function Note() {
  return (
  <div classname="note">
  <h1> Javascript and React.js</h1>
  <p> This was an amazing bootcamp taken by Shaurya Sinha.
  We covered everything from Scatch including Javascript, react.js.HTML.</p>
  </div>
  );
}     

export default Note;