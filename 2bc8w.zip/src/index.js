import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1> hi </h1>
  </div>,
  document.getElementById("root")
);
